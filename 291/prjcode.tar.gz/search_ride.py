import sqlite3
import time

#•members(email, name, phone, pwd)
#•cars(cno, make, model, year, seats, owner)
#•locations(lcode, city, prov, address)
#•rides(rno, price, rdate, seats, lugDesc, src, dst, driver, cno)
#•bookings(bno, email, rno, cost, seats, pickup, dropoff)
#•enroute(rno, lcode)
#•requests(rid, email, rdate, pickup, dropoff, amount)
#•inbox(email, msgTimestamp, sender, content, rno, seen)


def get_choice(locations,c,conn):  ##### 公用build in
    index = 0
    valid_choice = False
    while valid_choice == False:
        after = False
        before = False
        print('  | location code | city | Province | Address |')
        for i in range(min(len(locations)-index,5)):
            print(str(i+1)+': '+str(locations[i+index]))
        if index+5 < len(locations) :
            print ('Enter A to see more locations after them.')
            after = True
        if index > 0:
            print ('Enter B to see more locations before them.')     
            before = True
        choice = input('Please select the location: ')
        try:
            choice =int(choice)
        except:
            if choice.lower() == 'a' and after == True:
                index +=5
            elif choice.lower() == 'b' and before == True:
                index -= 5
            else:
                print('\n'+'Invalid input, please try again.'+'\n')
        else:
            if choice in range(1,7):
                valid_choice = True
            else:
                print('\n'+'Invalid input, please try again.'+'\n')

    return locations[choice-1]
    
def search_locations(c,conn):
    valid_input = False
    loc = []
    loc2= []
    c.execute("Select * from rides;")
    rid_rows=c.fetchall()        
    c.execute("Select * from locations;")
    loc_rows=c.fetchall()
    c.execute("Select * from enroute;")
    enroute_rows=c.fetchall()    
    for i in range(len(rid_rows)):  
        for j in range(len(loc_rows)):
            #print(rid_rows[i][5],rid_rows[i][6],loc_rows[j][0])
            if rid_rows[i][5] == loc_rows[j][0] or rid_rows[i][6] == loc_rows[j][0]:
                loc.append(loc_rows[j])
            if rid_rows[i][5] == loc_rows[j][0] and rid_rows[i][6] == loc_rows[j][0]:
                loc.append(loc_rows[j])
        enrouted = False
        for j in range(len(enroute_rows)):
            if rid_rows[i][0] == enroute_rows[j][0]:
                for k in range(len(loc_rows)):
                    if enroute_rows[j][1] == loc_rows[k][0]:
                        loc.append(loc_rows[k])
                enrouted = True
        if enrouted == False:
            loc.append([''])
                
    while valid_input == False:
        c.execute("Select * from rides;")
        rid_rows=c.fetchall()         
        keyword = input('Please enter at most 3 keywords of the location,seperate by space: ').lower()
        keyword = keyword.split(' ')
        remove_list = []
        for i in range(int(len(loc)/3)):
            remove = False
            i_list = []
            for word in loc[3*i]:
                i_list.append(word.lower())
            for word in loc[3*i+1]:
                i_list.append(word.lower())
            for word in loc[3*i+2]:
                i_list.append(word.lower())            
            for j in range(len(keyword)):   
                if keyword[j] not in i_list:
                    remove = True
            if remove == True:
                remove_list.append(rid_rows[i])
        for i in range(len(remove_list)):
            rid_rows.remove(remove_list[i])
        if len(rid_rows) != 0:
            valid_input = True
        else:
            print('Location does not exist, please try again.')
    return rid_rows

def search_ride(c,conn):   
    lst = search_locations(c,conn)
    return get_choice(lst,c,conn)

def main(email,c,conn):
    member = email 
    lst = search_ride(c,conn)
    rno,email = lst[0],lst[7]
    date = str(time.strftime('%Y-%m-%d', time.localtime()))
    contents = input('Please enter what you want to send to the driver: ')
    c.execute("INSERT INTO inbox (email, msgTimestamp, sender, content, rno, seen) VALUES (?,?,?,?,?,?)",(email, date,member,contents,rno,'n'))
    conn.commit()
    print('Email successfully sent.')
