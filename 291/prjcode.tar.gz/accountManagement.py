import sqlite3
import SearchAndDeleteRideRequests
import sqlManagement
import BookMembersOrCancelBookings
import PostRideRequest
import offer_ride
import search_ride
import re
import sys
import os
import base64
import getpass


def checkMailBox(email,c,conn):
    
    c.execute("select count(email) from inbox where seen = 'n' and email=:email", {"email":email})
    emails = c.fetchall()
    if emails[0][0] == 0:
        print("+++++++++++++++++++++++++++++++++++++++++++++")
        print("You don't have any emails unchecked!")
        print("+++++++++++++++++++++++++++++++++++++++++++++")
        return
    userChoice = input("You have %d emails unchecked, want to check out right now?(y/n)" % emails[0][0])
    if userChoice == 'y' or userChoice=='Y':#show emails
        while True:
            c.execute("select * from inbox where seen = 'n' and email=:email", {"email":email})
            emailsList = c.fetchall()
            print("( email | msgTimeStamp | sender | content | rno | seen )")
            for i in emailsList:
                print(i)
            userChoice2 = input("Once finished reading, Press 'y'")
            #update email condition
            if userChoice2 == 'y' or userChoice2 == 'Y':
                #for i in emailsList:
                c.execute('''UPDATE inbox SET seen = 'y' where email =:email;''', {"email":email})
                conn.commit()
                print("All unckecked emails ar checked!")
                break
            else:
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
    else:
        return

def get_sms_operator(email,password,c,conn):
    #c.execute("Select email, pwd from members")
    c.execute("select * from members where email =? and pwd = ?;", (email, password))
    rows = c.fetchall()
    if rows:
        print("You have been successfully login.")
        return True
    else:
        print('Account does not exist')
        return False

def log_in(c,conn):
    email = input('Please enter your account email: ')
    #password = input('Please enter the password: ')
    password = getpass.getpass()
    valid = get_sms_operator(email,password,c,conn)
    if valid:
    	functionalities(email,password,c,conn)
    else:
        return
    
'''
        if (email, password) == row:
            #if_login = True
            print('Nice, you have been successfully login.')
            functionalities(email,password,c,conn)
            return
            #return email'''

def functionalities(email,password,c,conn):
    usersChoiceValidation = False
    while not usersChoiceValidation:
        print("##############################################\n"*2)
        print("Hi there, what are you going to do?")
        print("Here is your option menu:")
        print("press 1: Offer a ride")
        print("press 2: Search for a ride")
        print("press 3: Book members or cancel bookings")
        print("press 4: Post ride requests")
        print("press 5: Search and delete ride requests")
        print("press 6: To view in box")
        print("press 7: Log out")
        usersChoice = input("So, your choice is: ")
        if usersChoice == '1':
            offer_ride.offer_ride(email,c,conn)
        elif usersChoice == '2':
            search_ride.main(email,c,conn)
        elif usersChoice == '3':
            BookMembersOrCancelBookings.getMember(email,password,c,conn)
        elif usersChoice == '4':
            PostRideRequest.execute(email,password,c,conn)
        elif usersChoice == '5':
            SearchAndDeleteRideRequests.getMember(email,password,c,conn)
        elif usersChoice == '7':
            print("##############################################")
            print("Thanks for using our program!")
            return
        elif usersChoice == '6':
            checkMailBox(email,c,conn)
        else:
            print("Sorry we can't read your choice, please try again.")



def register(c,conn):
    e_mail = input('Please enter a valid email address: ')
    l_name = input('Please enter your name: ')
    l_phone = int(input('Please enter your phone number: '))
    l_password = getpass.getpass()
    if not checkEmail(e_mail,c,conn):
        print("Sorry, you gave an invalid email!!")
        return
    c.execute('''INSERT INTO members (email, name, phone, pwd) VALUES (?,?,?,?);''',
              (e_mail, l_name, l_phone, l_password))
    conn.commit()
    valid_input = False
    while valid_input == False:
        answer = input('Want to login right now?(y/n)')
        if answer == 'y' or answer == 'Y':
            log_in(c,conn)

        elif answer == 'N' or answer == 'n':
            print("##############################################")
            print("Thanks for using our program!")
            break
        else:
            print("Sorry, please give an invalid input.")
            valid_input = False
    return

def checkEmail(e_mail,c,conn):
    EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")
    if not EMAIL_REGEX.match(e_mail):
        return False
    else:
        return True
def start(c,conn):
    while True:
        print("##############################################\n"*3)
        print("welcome to our onlineTaxi Mini-program")
        valid_input = False
        while valid_input == False:
            login = input('Now you can: Login(press 1) or register(press 2) or exit(press e):')
            if login == '1' or login == '2':
                valid_input = True
            if login == "e" or login == "E":
                return
        if login == '1':
            log_in(c,conn)
        if login == '2':
            register(c,conn)
    
    return
def main():
    #get database:
    if len(sys.argv) != 2:
        print("No input database!")
        return
    if os.path.isfile(sys.argv[1]) is not True:
        print("Invalid database!")
        return
    conn = sqlite3.connect("./" + str(sys.argv[1]))
    c = conn.cursor()
    conn.commit()
    start(c,conn)
    conn.commit()
    conn.close()
    return
if __name__ == "__main__":
    main()
