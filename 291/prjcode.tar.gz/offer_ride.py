import sqlite3
import time

#•members(email, name, phone, pwd)
#•cars(cno, make, model, year, seats, owner)
#•locations(lcode, city, prov, address)
#•rides(rno, price, rdate, seats, lugDesc, src, dst, driver, cno)
#•bookings(bno, email, rno, cost, seats, pickup, dropoff)
#•enroute(rno, lcode)
#•requests(rid, email, rdate, pickup, dropoff, amount)
#•inbox(email, msgTimestamp, sender, content, rno, seen)

    
def get_choice(locations,c,conn):  ##### 公用build in
    while len(locations)>5:
        L1 = locations[:5]
        print('  | location code | city | Province | Address |')
        for i in range(0,5):
            print(str(i+1)+': '+str(locations[0]))
            locations.remove(locations[0])
        print('6: Show more')
        valid_choice = False
        while valid_choice == False:
            try:
                choice = int(input('Please select the location : '))
            except:
                print('Invalid input, please try again.')
            else:
                if choice in range(1,7):
                    valid_choice = True
                else:
                    print('Invalid input, please try again.')
        if choice == 6:
            pass
        else:
            return  L1[choice-1]
    print('  | location code | city | Province | Address |')
    for i in range(len(locations)):
        print(str(i+1)+': '+ str(locations[i]))
        valid_choice = False
        while valid_choice == False:
            try:
                choice = int(input('Please select the location : '))
            except:
                print('Invalid input, please try again.')
            else:
                if choice in range(1,len(locations)+1):
                    valid_choice = True   
                else:
                    print('Invalid input, please try again.')
        return locations[choice-1]

    
def get_location(key_word,lst,c,conn):
    locations = []
    valid_input = False
    for row in lst:
        for word in row:
            if key_word.lower() == word.lower():
                locations.append(row)
                valid_input = True
    if valid_input == False:
        return False
    return (get_choice(locations,c,conn))
            
                   
def offer_ride(member,c,conn):
    c.execute("Select * from locations;")
    loc_rows=c.fetchall()    
    date = input('Please enter the date you can offer rides: ')
    while True:
        try:
            no_seats = int(input('How many seats can you offer: '))
        except:
            print('Invalid input, please try again.')
        else:
            break
    while True:
        try:
            price_seat = float(input('Whats the price of each seat you offer $: '))
        except:
            print('Invalid input, please try again.')
        else:
            break
    while True:
        try:
            lug = float(input('How much addtional price per luggage $?: '))
        except:
            print('Invalid input, please try again.')
        else:
            break
    src = False
    while not src:
        src = get_location(input('Where do you want to start at (enter only 1 location code or city name or province name): '),loc_rows,c,conn)
        if not src:
            print('Location does not exist, please try again.')
    src = src[0]
    dst = False
    while not dst:
        dst = get_location(input('Where do you want to end at (enter only 1 location code or city name or province name): '),loc_rows,c,conn)
        if not dst:
            print('Location does not exist, please try again.')
    dst = dst[0]
    enroute = False
    while not enroute:
        userChice = input("Do you want to add any enroutes? (y/n")
        if userChice.upper() == 'Y':
            enroute = get_location(input('which enroute location you want to add (enter only 1 location code or city name or province name): '), loc_rows,c,conn)
            if not enroute:
                print('Location does not exist, please try again.')
            else:
                c.execute("Select * from rides;")
                rid_row = c.fetchall()
                rno1 = len(rid_row) + 1
                c.execute("INSERT INTO enroute values (:rno, :lcode);", {"rno": rno1, "lcode": enroute[0]})
        elif userChice.upper() == 'N':
            break
        else:
            print("Sorry I dont understand your input")

    if_car = False
    valid_input = False
    while valid_input == False or if_car == False:
        cno = input('Please enter the car number of your car or dont enter anything: ')
        print(cno)
        if cno!= '':
            try:
                cno = int(cno)
                valid_input = True
            except:
                print('Invalid car number!')
        else:
            cno = None
            valid_input = True
            break
        c.execute('select * from cars')
        car_lst = c.fetchall()            
        cno_lst = []
        if valid_input == True:
            for i in range(len(car_lst)):
                cno_lst.append(car_lst[i][0])
                if car_lst[i][0] == cno and car_lst[i][5] == member:
                    if_car = True
                elif car_lst[i][0] == cno and car_lst[i][5] != member:
                    print('This is not your car,please try again.')
            if cno != None and cno not in cno_lst:
                print('Car does not exist, please try again.')
    c.execute("Select * from rides;")
    rid_rows=c.fetchall()    
    rno = len(rid_rows)+1
    c.execute("INSERT INTO rides (rno, price, rdate, seats, lugDesc, src, dst, driver, cno) VALUES (?,?,?,?,?,?,?,?,?)",(rno,price_seat,date,no_seats,lug,src,dst,member,cno))
    conn.commit()
    print('Ride has successfully been added')










        
    
