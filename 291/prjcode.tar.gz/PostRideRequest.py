import sqlite3

import sqlManagement
import accountManagement


def execute(email,password,c,conn):
    c.execute('Select * from members where members.email =:email;', {"email": email} )
    tempMembersList = c.fetchall()
    #print(tempMembersList)-passed

    member = tempMembersList[0] #get the tuple of this member info
    PostRideRequest(member,c,conn)
    return
    
def PostRideRequest(member,c,conn):
    
    
    #check if your input location code is valid
    while True:
        c.execute("Select lcode from locations")
        lcode_list = c.fetchall()
        lcode_list2 = []
        for i in lcode_list:
            lcode_list2.append(i[0])

        print("##############################################")
        date = input('Please enter the date you wish to take a ride (YYYY-MM-DD):')
        price_seat = float(input('Please enter the amount you are willing to pay(enter a float number): '))
        src = input('Please enter the code for the pick-up location (enter a location code): ')
        if src not in lcode_list2:
            print('the code for the pick-up locstion is invalid')
        else:
            dst = input('Please enter the code for the drop-off location (enter a location code): ')
            if dst not in lcode_list2:
                print('the code for the drop-off location is invalid')
            
        if src in lcode_list2 and dst in lcode_list2:
            break

    c.execute("Select * from requests")
    rows=c.fetchall()
    rideid = len(rows)+1
    c.execute("INSERT INTO requests (rid, email, rdate, pickup, dropoff, amount) VALUES (?, ?, ?, ?, ?, ?)", (rideid, member[0], date, src, dst, price_seat))
    conn.commit()
    print("Your request has been successfully added into database !")
    return

