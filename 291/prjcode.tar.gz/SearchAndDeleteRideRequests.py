import sqlite3

import sqlManagement
import accountManagement

def getMember(email,password,c,conn):
    c.execute('Select * from members where members.email =:email;', {"email": email} )
    tempMembersList = c.fetchall()
    #print(tempMembersList)-passed

    member = tempMembersList[0] #get the tuple of this member info
    SearchAndDeleteRideRequests(member,c,conn)

def stillWantToDoAnyThing():
    control = False
    while not control:
        print("##############################################")
        userChoice = input("Anything else want to do?(y/n)")
        if userChoice == 'y' or userChoice == 'Y':
            return True
        elif userChoice == 'N' or userChoice == 'n':
            return False
        else:
            print("Sorry, we don't understand your input.")

def SearchAndDeleteRideRequests(member,c,conn):
    control = False
    while not control:
        print("##############################################")
        print("Now, you can deal with requests! Here are some options: ")
        print("1: View all requests or delete them")
        print("2: Search or Add requests")
        print("q: to exit this ")
        userChoice = input("Now your choice is: ")
        if userChoice == "1":
            ViewRequests(member,c,conn)
            if stillWantToDoAnyThing():
                continue
            else:
                return
        if userChoice == "2":
            selectARequest(member,c,conn)
            if stillWantToDoAnyThing():
                continue
            else:
                return
        elif userChoice == "q":
            control = True
        else:
            print("Sorry, we don't understand your input.")
    return
def selectARequest(member,c,conn):
    while True:
        print("Now you can search the requests by give a location code or city name, what is your choice?")
        userChoice = input("Press 1 to choose by location code, " + "\n"+"Press 2 to choose by city name: ")
        if userChoice == '1':
            searchByLocationCode(member,c,conn)
            return
        elif userChoice == '2':
            searchByName(member,c,conn)
            return
        else:
            print("Sorry, we don't understand your input.")
            return

    return
def searchByLocationCode(member,c,conn):
    userChoice = input("Please give a location code: ")
    c.execute("select pickup from requests;")
    allPickUp = c.fetchall()
    allPickUpList = []
    for i in allPickUp:
        allPickUpList.append(i[0].lower())
    if userChoice.lower() not in allPickUpList:
        print("Sorry, your given location code does not exist in requests!")
        return
    c.execute("select * from requests where pickup like :pickup;", {"pickup":userChoice })
    theSelectedRequestList = c.fetchall()

    ridList = [] #store rids for validation later on// int list
    for i in theSelectedRequestList:
        ridList.append(i[0])

    #initialize variables for changing pages...
    control = 1
    maxControl = 1 + len(theSelectedRequestList)/5
    while True:
        print("Here is all all requests regards with the given location code: ")
        if len(ridList) == 0:
            print("SORRY, no request linked with this location!")
            break
        print("(rid | email | rdate | pickup | dropoff | amount)")
        for theSelectedRequest in theSelectedRequestList[(control-1)*5:control*5]:
            print(theSelectedRequest)
        userChoice2 = input("Press 'z' for next page, press 'a' for previous page, press 'q' for exits, press 'c' for selecting a request: ")
        if len(theSelectedRequestList)> 5:
            if userChoice2 == 'z' or userChoice2 == 'Z':
                control+=1
                if control > maxControl:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("This is already the last page!")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    control-=1
            elif userChoice2 == 'a' or userChoice2 == 'A':
                control-=1
                if control <1:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("This is already the first page!")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    control += 1
            elif userChoice2 != 'q' and userChoice2 != 'q' and userChoice2 != 'c' and userChoice2 != 'C':
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
        if userChoice2 == 'q' or userChoice2 == 'Q':
            break
        elif userChoice2 == 'c' or userChoice2 == 'C':
            userChoice3 = input("Select a request by given its request ID (rid)")
            if userChoice3.isdigit():
                if int(userChoice3) not in ridList:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("Sorry, your given rid is not exist in requests")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                else:
                    #the case that user input is correct and can send message now!
                    #match rid with email, match email with inbox
                    currentDate = sqlite3.time.strftime('%Y-%m-%d', sqlite3.time.localtime(sqlite3.time.time()))
                    senderEmail = member[0]
                    c.execute("select email,pickup from requests where rid =:rid;", {"rid":int(userChoice3) })
                    request = c.fetchone()
                    receiverEmail = request[0]
                    pickUp = request[1]
                    #get a valid rno number
                    c.execute("select rno from rides where src =:pickup;", {"pickup":pickUp})
                    rno = c.fetchone()
                    if rno == None:
                        c.execute("select rno from rides;")
                        rno = c.fetchone()[0]
                    else: rno = rno[0]
                    messages = "Can you check out a ride with a rno %s" %str(rno)
                    c.execute(''' insert into inbox values
                            (:receiverEmail, :currentDate, :senderEmail, :message, :rno, 'n');''',{"receiverEmail": receiverEmail, "currentDate":currentDate, "senderEmail":senderEmail, "message":messages, "rno":rno})
                    conn.commit()
                    return
            else:
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")

        else:
            if len(theSelectedRequestList)<= 5:
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
    return

def searchByName(member,c,conn):
    userChoice = input("Please give a city name: ")
    c.execute("select city from locations;")
    allPickUp = c.fetchall()
    allPickUpList = []
    for i in allPickUp:
        allPickUpList.append(i[0].lower())
    if userChoice.lower() not in allPickUpList:
        print("Sorry, your given city name does not exist in locations!")
        return
    c.execute("select rid,email,rdate,pickup,dropoff,amount from requests, locations where city like :city and lcode = pickup;", {"city": userChoice})
    theSelectedRequestList = c.fetchall()
    ridList = []  # store rids for validation later on// int list
    for i in theSelectedRequestList:
        ridList.append(i[0])
    # initialize variables for changing pages...
    control = 1
    maxControl = 1 + len(theSelectedRequestList) / 5
    while True:
        print("Here is all all requests regards with the given City Name: ")
        if len(ridList) == 0:
            print("SORRY, no request linked with this location!")
            break
        print("(rid | email | rdate | pickup | dropoff | amount)")
        for theSelectedRequest in theSelectedRequestList[(control-1)*5:control*5]:
            print(theSelectedRequest)
        userChoice2 = input("Press 'z' for next page, press 'a' for previous page, press 'q' for exits, press 'c' for selecting a request: ")
        if len(theSelectedRequestList)> 5:
            if userChoice2 == 'z' or userChoice2 == 'Z':
                control+=1
                if control > maxControl:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("This is already the last page!")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    control-=1
            elif userChoice2 == 'a' or userChoice2 == 'A':
                control-=1
                if control <1:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("This is already the first page!")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    control += 1
            elif userChoice2 != 'q' and userChoice2 != 'q' and userChoice2 != 'c' and userChoice2 != 'C':
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
        if userChoice2 == 'q' or userChoice2 == 'Q':
            break
        elif userChoice2 == 'c' or userChoice2 == 'C':
            userChoice3 = input("Select a request by given its request ID (rid)")
            if userChoice3.isdigit():
                if int(userChoice3) not in ridList:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("Sorry, your given rid is not exist in requests")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                else:
                    #the case that user input is correct and can send message now!
                    #match rid with email, match email with inbox
                    currentDate = sqlite3.time.strftime('%Y-%m-%d', sqlite3.time.localtime(sqlite3.time.time()))
                    senderEmail = member[0]
                    c.execute("select email,pickup from requests where rid =:rid;", {"rid":int(userChoice3) })
                    request = c.fetchone()
                    receiverEmail = request[0]
                    pickUp = request[1]
                    #get a valid rno number
                    c.execute("select rno from rides where src =:pickup;", {"pickup":pickUp})
                    rno = c.fetchone()
                    if rno == None:
                        c.execute("select rno from rides;")
                        rno = c.fetchone()[0]
                    else: rno = rno[0]
                    messages = "Can you check out a ride with a rno %s" %str(rno)
                    c.execute(''' insert into inbox values
                                                (:receiverEmail, :currentDate, :senderEmail, :message, :rno, 'n');''',
                              {"receiverEmail": receiverEmail, "currentDate": currentDate, "senderEmail": senderEmail,
                               "message": messages, "rno": rno})
                    conn.commit()
                    return
            else:
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")

        else:
            if len(theSelectedRequestList)<= 5:
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
    return

def ViewRequests(member,c,conn):
    c.execute("Select * from requests where requests.email =:email;", {"email": member[0]})
    allUsersRequests = c.fetchall()
    ridList = []
    print("Here is all of your requests: ")
    print("(rid | email | rdate | pickup | dropoff | amount)")
    for userRequest in allUsersRequests:
        ridList.append(str(userRequest[0]))
        print(userRequest)
    if len(ridList) == 0:
        print("SORRY, you have no request right now!")
        return
    DeleteRequests(ridList,c,conn)


def DeleteRequests(ridList,c,conn):
    while True:
        userChoice = input("Do you want to can delete any requests?(y/n): ")
        if userChoice == 'y' or userChoice == 'Y':
            print("Which requests you want to cancel?")
            userChoice2 = input("Hint: You can enter the request id (rid) and split them with space: ")
            splitedUserChoice2 = userChoice2.split()
            control = True
            for number in splitedUserChoice2:
                if number in ridList:
                    continue
                else:
                    control = False
                    break
            if control: #send message to members whose bookings is cancelled and delete
                selectedRequests = []
                for i in splitedUserChoice2:
                    selectedRequests.append(int(i))
                for request in selectedRequests:
                    c.execute("DELETE FROM requests WHERE rid =:rid", {"rid": request})
                    conn.commit()
                return 1
            else:
                print("Some request ID (rid) you entered are not in database!")


            return False
        elif userChoice == 'N' or userChoice == 'n':
            return False
        else:
            print("Sorry, we don't understand your input.")
    return