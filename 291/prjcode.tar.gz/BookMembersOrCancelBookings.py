import sqlite3

import sqlManagement

'''The member should be able to list all bookings on rides s/he offers and cancel any booking'''
'''For any booking that is cancelled (i.e. being deleted from the booking table), a proper message should be sent to the member whose booking is cancelled'''
'''the member should be able to book other members on the rides they offer.'''
'''system should list all rides the member offers with the number of available seats for each ride (i.e., seats that are not booked)'''
''' If there are more than 5 matching rides, at most 5 will be shown at a time, and the member will have the option to see more.'''
'''The member should be able to select a ride and book a member for that ride by entering the member email, the number of seats booked, the cost per seat, and pickup and drop off location codes.'''
'''Your system should assign a unique booking number (bno) to the booking. '''
'''Your system should give a warning if a ride is being overbooked (i.e. the number of seats booked exceeds the number of seats offered), but will allow overbooking if the member confirms it.'''
'''After a successful booking, a proper message should be sent to the other member that s/he is booked on the ride.'''

def getMember(email,password,c,conn):
    c.execute('Select * from members where members.email =:email;', {"email": email} )
    tempMembersList = c.fetchall()
    print(tempMembersList)
    member = tempMembersList[0] #get the tuple of this member info
    bookMembersOrCancelBookings(member,c,conn)
    return member

def bookMembersOrCancelBookings(member,c,conn):

    print("##############################################")
    control = False
    while not control:
        print("Now, you can deal with bookings! Here are some options: ")
        print("1: List all bookings or cancel the bookings.")
        print("2: Book on a ride")
        print("q: to exit this function ")
        userChoice = input("Now your choice is: ")
        if userChoice == "1":
            listAllBookings(member,c,conn)
            if stillWantToDoAnyThing():
                continue
            else:
                return
        if userChoice == "2":
            bookTheBooking(member,c,conn)
            if stillWantToDoAnyThing():
                continue
            else:
                return
        elif userChoice == "q":
            control = True
        else:
            print("Sorry, we don't understand your input.")
    return
def bookTheBooking(member,c,conn):

    #book a booking
    rnoLIst = []
    c.execute(''' 
                    Select r.rno, r.price, r.rdate, r.seats,r.lugDesc, r.src, r.dst, r.driver, r.cno, (case when sum(b.seats) is NULL then r.seats when r.seats - (sum(b.seats))>=0 then r.seats - (sum(b.seats)) else 0 end) as 'avaliable seats'
                    from rides r left outer join bookings b on b.rno = r.rno
                    where r.driver =:email
                    group by r.rno
                    ;''', {"email": member[0]})
    ridesByMembers = c.fetchall()
    #avaliable seats exceed always 0
    for i in ridesByMembers:
        if i[len(i)-1] < 0:
            c.execute('''UPDATE bookings SET seen = 'y' where email =:email;''', {"email":  member[0]})
            conn.commit()
    #gets all rides rno
    for i in ridesByMembers:
        rnoLIst.append(i[0])
    control = 1
    maxControl = 1 + len(ridesByMembers)/5
    while True:
        print("Here is all the rides you offered with avaliable seats: ")
        if len(rnoLIst) == 0:
            print("You have not offered any rides yet!")
            break
        print("(rno | price | rdate | seats | lugDesc | src | dst | driver | cno | avaliable seats )")
        for ridesByMember in ridesByMembers[(control-1)*5:control*5]:
            print(ridesByMember)
        userChoice2 = input("Press 'z' for next page, press 'a' for previous page, press 'q' for exits, press 'c' for select a ride and book a member: ")
        if len(ridesByMembers)> 5:
            if userChoice2 == 'z' or userChoice2 == 'Z':
                control+=1
                if control > maxControl:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("This is already the last page!")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    control-=1
            elif userChoice2 == 'a' or userChoice2 == 'A':
                control-=1
                if control <1:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("This is already the first page!")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    control += 1
            elif userChoice2 != 'q' and userChoice2 != 'q' and userChoice2 != 'c' and userChoice2 != 'C':
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
        if userChoice2 == 'q' or userChoice2 == 'Q':
            break
        elif userChoice2 == 'c' or userChoice2 == 'C':
            #book a member b on member A's (your) rides
            userChoice3 = input("Which ride do you want to select? Please enter the rides number(rno): ")
            if userChoice3.isdigit():
                if int(userChoice3) not in rnoLIst:
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                    print("Sorry, your given rides number does not exist in rides")
                    print("+++++++++++++++++++++++++++++++++++++++++++++")
                else:
                    #given an appropriate rides
                    #start to ask who you want to book?
                    print("Now you have chosen a ride. So who you want to book?")
                    userChoice4 = input("Please give a member email, the number of seats booked, the cost per seat, and pickup and drop off location codes(split them with only one space): ")
                    splitedUserChoice4 = userChoice4.split()
                    #check validation
                    IfValid = checkValidaionForBooking(splitedUserChoice4,userChoice3,c,conn)
                    if not IfValid:
                        return False
                    #booking successful, assign this booking into tables and send message
                    print("Your infos are valid")
                    signBooksAndSendMessage(splitedUserChoice4,userChoice3,member,c,conn)
                    return
            else:
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
            return
        else:
            if len(ridesByMembers)<= 5:
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
    return
def signBooksAndSendMessage(splitedUserChoice4,userChoice3,member,c,conn):

    #get a unique booking number
    c.execute("select bno from bookings;")
    bnos = c.fetchall()
    newBno = bnos[len(bnos)-1][0] +1
    #get the guy's email who is booked
    receiverEmail = splitedUserChoice4[0]
    #get the rno
    rno = userChoice3
    #get the cost
    cost = float(splitedUserChoice4[1]) * float(splitedUserChoice4[2])
    #get the seatbooked
    seats = int(splitedUserChoice4[1])
    #get the pickup an drop off
    pickup = splitedUserChoice4[3]
    dropOff = splitedUserChoice4[4]
    c.execute(''' insert into bookings values
                    (:newBno,:receiverEmail,:rno, :cost, :seats,:pickup,:dropoff);''' ,{"newBno":int(newBno), "receiverEmail":receiverEmail, "rno": int(rno),"cost": cost, "seats": seats,"pickup":pickup,"dropoff":dropOff})
    conn.commit()
    #send message
    messages = 'Hi there, you are booked on the ride with ride number(rno) %s' %rno
    currentDate = sqlite3.time.strftime('%Y-%m-%d', sqlite3.time.localtime(sqlite3.time.time()))
    senderEmail = member[0]
    c.execute(''' insert into inbox values
                (:receiverEmail,:currentDate,:senderEmail,:messages,:rno, 'n');''', {"receiverEmail": receiverEmail,"currentDate":currentDate, "senderEmail":senderEmail, "messages":messages, "rno":int(rno) })
    conn.commit()




def checkValidaionForBooking(splitedUserChoice4,userChoice3,c,conn):

    control = True
    #get members email
    c.execute("select email from members;")
    memberEmails = c.fetchall()
    memberEmailsList = []
    for i in memberEmails:
        memberEmailsList.append(i[0])
    #get info of selected ride
    c.execute("select * from rides where rno=:rno;",{"rno": userChoice3})
    selectedRide = c.fetchone()
    #get number of avaliable seats
    c.execute("select seats from bookings where rno =:rno;",{"rno": userChoice3})
    numOfBookedSeats = c.fetchone()
    if numOfBookedSeats == None:
        numOfBookedSeats = [0]
    numOfAvaliableSeats = selectedRide[3] - numOfBookedSeats[0]
    #get all location codes
    c.execute("select lcode from locations;")
    locations = c.fetchall()
    locationsList = []
    for i in locations:
        locationsList.append(i[0])
    #start checking
    if splitedUserChoice4[0] not in memberEmailsList:   #check email validation, not check if email is self's
        control = False
        print("+++++++++++++++++++++++++++++++++++++++++++++")
        print("Sorry, your given members are not in our memberList.")
        print("+++++++++++++++++++++++++++++++++++++++++++++")
        return control
    if int(splitedUserChoice4[1]) > numOfAvaliableSeats:
        while True:
            confirm = input("The ride is being over booking, do you allow over booking? (y/n)")
            if confirm =='n' or confirm=='N':
                control= False
                return control
            elif confirm == 'y' or confirm == 'Y':
                break
            else:
                print("+++++++++++++++++++++++++++++++++++++++++++++")
                print("Sorry, we don't understand your input.")
                print("+++++++++++++++++++++++++++++++++++++++++++++")
    if int(splitedUserChoice4[1]) < 1 or float(splitedUserChoice4[2]) < 0:
        control = False
        print("+++++++++++++++++++++++++++++++++++++++++++++")
        print("Sorry, you cannot give a negative number!")
        print("+++++++++++++++++++++++++++++++++++++++++++++")
        return control
    if splitedUserChoice4[3] not in locationsList or splitedUserChoice4[4] not in locationsList:
        print(splitedUserChoice4[3],splitedUserChoice4[4])
        control =False
        print("+++++++++++++++++++++++++++++++++++++++++++++")
        print("Sorry, your given location code does not exist!")
        print("+++++++++++++++++++++++++++++++++++++++++++++")
        return control
        
    return control

def listAllBookings(member,c,conn):

    c.execute("Select * from rides where rides.driver =:email;", {"email": member[0]})
    ridesByMembers = c.fetchall()
    bnoList = []
    print("Here is all bookings on the rides you offered: ")
    print("(bno | email | rno | cost | seats | pickup | dropoff)")
    c.execute("Select * from bookings where bookings.rno in (Select rno from rides where rides.driver =:email);", {"email": member[0]})
    bookingNUmbers = c.fetchall()
    for i in bookingNUmbers:
        print(i)
        bnoList.append(str(i[0]))
    if len(bnoList) ==0:
        print("There is no bookings linked with your rides!")
        return
    deleteTheBookings(bnoList,member,c,conn)

def deleteTheBookings(bnoList,member,c,conn):

    while True:
        userChoice = input("Do you want to can cancel any bookings?(y/n): ")
        if userChoice == 'y' or userChoice == 'Y':
            print("Which bookings you want to cancel?")
            userChoice2 = input("Hint: You can enter the booking numbers (bno) and split them only one space: ")
            splitedUserChoice2 = userChoice2.split()
            #print(splitedUserChoice2)
            control = True
            for number in splitedUserChoice2:
                if number in bnoList:
                    continue
                else:
                    control = False
                    break
            if control: #send message to members whose bookings is cancelled and delete
                bookingEmails = []
                receiverEmailList = []
                for i in splitedUserChoice2:
                    c.execute("Select bno,email, rno from bookings where bookings.bno =:bno;",{"bno": int(i)})
                    email = c.fetchone()
                    bookingEmails.append(email)
                ##send message from here:
                senderEmail = member[0]
                currentDate = sqlite3.time.strftime('%Y-%m-%d', sqlite3.time.localtime(sqlite3.time.time()))
                for each in bookingEmails:
                    messages = 'Your booking number %s is cancelled regarded with rides number %s ' % (str(each[0]),str(each[2]))
                    c.execute(''' insert into inbox values
                                      (:each1, :currentDate, :senderEmail, :messages, :rno, 'n');''' ,{"each1":each[1] ,"currentDate":currentDate,"senderEmail":senderEmail ,"messages":messages,"rno":each[2]})
                    conn.commit()
                #delete bno from here:
                for bookings in bookingEmails:
                    c.execute("DELETE FROM bookings WHERE bno =:bno", {"bno": bookings[0]})
                    conn.commit()
                ##delete and send message ends
                return 1
            else:
                print("Some booking number(bno) you entered are not in database!")
            return False
        elif userChoice == 'N' or userChoice == 'n':
            return False
        else:
            print("Sorry, we don't understand your input.")




def stillWantToDoAnyThing():

    control = False
    while not control:
        print("##############################################")
        userChoice = input("Anything else want to do?(y/n)")
        if userChoice == 'y' or userChoice == 'Y':
            return True
        elif userChoice == 'N' or userChoice == 'n':
            return False
        else:
            print("Sorry, we don't understand your input.")
